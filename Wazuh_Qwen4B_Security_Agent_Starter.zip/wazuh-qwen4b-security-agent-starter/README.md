# Wazuh + Qwen3 4B Security Agent — ZCode Starter Pack

Bu paket, Wazuh ile olay tespiti, yerel Qwen3 4B ile olay açıklama/önceliklendirme ve güvenlik paneli geliştirmek için başlangıç belgeleri sağlar.

## İçerik
- `AGENTS.md`: Proje kökü için kalıcı geliştirme ve güvenlik kuralları.
- `phases/`: Her faz için geliştirme promptu ve ayrı doğrulama/test promptu.
- `skills/`: Ajanın ilgili görevlerde izleyeceği tekrar kullanılabilir beceri yönergeleri.
- `training/`: Fine-tuning gerekip gerekmediğini belirleme ve gerekirse veri/eğitim planı.
- `architecture.md`: Önerilen sistem mimarisi ve veri akışı.
- `acceptance-matrix.md`: Fazlar için kabul ölçütleri.

## ZCode'da kullanım
1. Bu paketi yeni projenin köküne kopyala.
2. Önce `AGENTS.md` ve `architecture.md` dosyalarını okut.
3. `phases/00-discovery.md` geliştirme promptunu çalıştır; henüz kod yazdırma.
4. Analiz raporunu incele, belirsizlikleri gider.
5. Her fazda önce geliştirme promptunu, ardından ayrı test promptunu çalıştır.
6. Testler geçmeden sonraki faza ilerleme. Test başarısızsa düzeltme yaptır ve test promptunu tekrar çalıştır.
7. Gerçek sunucularda otomatik engelleme/komut çalıştırma özelliğini başlangıçta etkinleştirme.

## Önemli
Bu paket örnek bir başlangıç planıdır; mevcut depo, Wazuh sürümü, dağıtım biçimi, işletim sistemi ve ZCode'un desteklediği ajan/skill biçimine göre uyarlanmalıdır. Wazuh API alanları, endpoint'ler ve konfigürasyonlar kurulu sürümün resmi dokümantasyonuyla doğrulanmalıdır. Üretim sisteminde değişiklik yapmadan önce yedek, staging ortamı ve geri dönüş planı gerekir.
